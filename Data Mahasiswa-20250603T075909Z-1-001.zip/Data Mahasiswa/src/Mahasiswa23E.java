public class Mahasiswa23E {
    public static void main(String[] args) {
        Mahasiswa m23 = new Mahasiswa();
        
        String nim = "22453465798";
        boolean result = m23.findMahasiswaByNim(nim);
        if(result){
            System.out.println("NIM Sudah Dipakai");
        }
        else{
            m23.insertMahasiswa
        (nim, "Andi", "BDG", "L");
        }

        m23.updateMahasiswa("Wati", "Bandung", "P", nim);
        
        m23.deleteMahasiswa(nim);
        m23.readMahasiswa();
        
    }
}
